Put your real photos in this folder using these EXACT filenames:

  cover.jpg            -> social-media link preview image (1200x630px)
  top-banner.jpg        -> wide image across the very top of the page (1600x500px)
  bottom-banner.jpg     -> wide image across the very bottom of the page (1600x500px)
  couple.jpg            -> round photo at the top of the invitation
  meseret.jpg           -> bride's photo near the bottom
  collage-1.jpg
  collage-2.jpg
  collage-3.jpg
  collage-4.jpg          -> 4 photos framing the couple's names mid-page
  gallery-01.jpg
  gallery-02.jpg
  gallery-03.jpg
  gallery-04.jpg
  gallery-05.jpg
  gallery-06.jpg
  gallery-07.jpg
  gallery-08.jpg
  gallery-09.jpg
  gallery-10.jpg
  gallery-11.jpg
  gallery-12.jpg          -> the 12 photo-gallery images

Delete this README.txt whenever you like — it won't affect the site.

Folder structure once you're done:

  your-repo/
    index.html
    images/
      cover.jpg
      top-banner.jpg
      bottom-banner.jpg
      couple.jpg
      meseret.jpg
      collage-1.jpg ... collage-4.jpg
      gallery-01.jpg ... gallery-12.jpg
